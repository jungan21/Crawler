# -*- coding: utf-8 -*-
import scrapy
from lianjiaspider4.items import HouseItem


class ExampleSpider(scrapy.Spider):
    name = 'example'
    allowed_domains = ['lianjia.com']
    start_urls = ['https://bj.lianjia.com/zufang']

    def parse(self, response):
        box = response.xpath('//*[@id="content"]/div[1]/div[1]')
        for num in range(1, 20):
            item = HouseItem()
            item['title'] = box.xpath('./div[%s]/div/p[1]/a/text()' % num).extract()[0]
            item['area'] = box.xpath('./div[%s]/div/p[2]/text()[2]' % num).extract()[0]
            item['monthly_rental'] = box.xpath('./div[%s]/div/span/em/text()' % num).extract()[0]
            yield item

for box in response.xpath('//*[@id="content"]/div[1]/div[1]'):
                                                                 ^
TabError: inconsistent use of tabs and spaces in indentation
